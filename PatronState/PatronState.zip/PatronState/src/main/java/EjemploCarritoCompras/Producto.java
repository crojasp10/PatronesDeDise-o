package EjemploCarritoCompras;

public class Producto {

    private String descripcion;
    private float precio;

    public Producto(String descripcion, float precio) {
        this.descripcion = descripcion;
        this.precio = precio;
    }
}
