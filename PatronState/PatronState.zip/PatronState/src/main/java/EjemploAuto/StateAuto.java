package EjemploAuto;

public interface StateAuto {

    void acelerar();

    void frenar();

    void contacto();
}
