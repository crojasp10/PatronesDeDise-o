package com.company;

public interface Comida {

    public double getPrecio();
}
