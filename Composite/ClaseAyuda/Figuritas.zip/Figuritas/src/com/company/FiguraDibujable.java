package com.company;

public interface FiguraDibujable {

     void dibujar();
}
